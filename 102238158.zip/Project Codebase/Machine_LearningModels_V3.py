
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import  classification_report,confusion_matrix
from sklearn import metrics
from sklearn import preprocessing

# *** CODE REFERNCE:

# The understaing of how functions work for RFC and SKLEARN FROM :
# https://www.youtube.com/watch?v=eM4uJ6XGnSM
# https://www.youtube.com/watch?v=0Lt9w-BxKFQ
# https://www.youtube.com/watch?v=0pP4EwWJgIU
# SKlearn Doccumntation

# As I was not able to find an efficent way to make a model that takes mulitple inputs
# I created different models for different inputs to predict the quality based on the given feature
# the final outcome would be a combination of the overall prediction for each feature independly
# All models depend on incremental learning , where a data set is used for inital predicted but is not fixed.
# This is due to the feature of accuracy check provided to user.
# The implementation of oop + ML inspired from : https://medium.com/analytics-vidhya/oop-machinelearning-powerful-a9b936a8db48


#  **************************** MACHINE LEARNING Section ****************************

# * MODEL 1: Using RandomForestClassifier , this class predicts is the sleep enough based on given hrs
class PredictQualityHrs (object):

  # Conatins the model and the importation of Data set
  def __init__(self):
  
    self.n = 50
    self.model = RandomForestClassifier(n_estimators = self.n)
    self.sleepHRS = pd.read_csv('HrsDataSet.csv',sep = ',')

# Preprocessing is done to alter the diemnsionality of the data to fit the model
  def encode(self):
    preProcess = preprocessing.LabelEncoder()
    self.encodedHrs = preProcess.fit_transform(self.sleepHRS['Hours'])

# the construction of model is mainly done here
  def buildModel(self):

      target = self.sleepHRS['Enough']
      data = self.encodedHrs

      if len(self.encodedHrs)> 1*pow(10,6):
        self.model.warm_start = True
      self.Xtrain,self.Xtest,self.Ytrain,self.Ytest = train_test_split(data,target,test_size = 0.30 )
      self.Xtrain = self.Xtrain.reshape(-1,1) 
      self.Xtest = self.Xtest.reshape(-1,1)
      self.model.fit(self.Xtrain, self.Ytrain)

  # Prints a classification report which shows the performance of the model
  # in relation to the test and train samples randomly selected above 
  # If intrested in seeing it , uncomment the line in the test cases
  def getClassificationReport(self):
      self.Xtest2 = self.model.predict(self.Xtest)
      return print(classification_report(self.Ytest,self.Xtest2,zero_division=1))

  def predictIsItEnough (self,encodedH):
      # print(encodedH)

      # The extra brackets is trasform data from 1D to 2D 
      # as predict does not support 1D

      return self.model.predict([encodedH])

  def increaseEstimators(self):
    self.n += 1

    
        
# # CODE TEST CASES :
# print('PredictQualityHrs' )
# # Constructing the model 
# myModel = PredictQualityHrs()
# myModel.encode()
# myModel.buildModel()
# myModel.getClassificationReport()
# print(myModel.predictIsItEnough([7]))
# print(myModel.predictIsItEnough([7]))
# print(myModel.predictIsItEnough([1]))
# print(myModel.predictIsItEnough([2]))
# print(myModel.predictIsItEnough([3]))
# print(myModel.predictIsItEnough([5]))
# print(myModel.predictIsItEnough([4]))
# print(myModel.predictIsItEnough([23]))
# print(myModel.predictIsItEnough([11]))
# print(myModel.predictIsItEnough([6]))
# print(myModel.predictIsItEnough([7]))
# print(myModel.predictIsItEnough([8]))
# print(myModel.predictIsItEnough([5]))
# print(myModel.predictIsItEnough([1]))
# print(myModel.predictIsItEnough([0]))

# As its hard to predict if sleep was enough based on dinner alone
# as excersie alone . 2 seprate models will predict tiredness based on dinner and 
# excercise and the averge of that will be used to predict overall quality 

# MODEL 2 : PREDICT TIREDNESS BASED ON DINNER 
class PredictTirednessBasedOnDinner (object):

  # Conatins the model and the importation of Data set
  def __init__(self):
  
    self.n = 50
    self.model = RandomForestClassifier(n_estimators = self.n)
    self.sleepData = pd.read_csv('HrsDataSet.csv',sep = ',')

# Preprocessing is done to alter the state of the data to fit the model 
# No = 0 ,  Yes = 1
  def encode(self):
    self.preProcess = preprocessing.LabelEncoder()
    self.encodedDinner = self.preProcess.fit_transform(self.sleepData['Dinner'])

# the construction of model is mainly done here
  def buildModel(self):

      target = self.sleepData['Tired ']
      data = self.encodedDinner

      if len(self.encodedDinner)> 1*pow(10,6):
        self.model.warm_start = True

      self.Xtrain,self.Xtest,self.Ytrain,self.Ytest = train_test_split(data,target,test_size = 0.30 )
      self.Xtrain = self.Xtrain.reshape(-1,1) 
      self.Xtest = self.Xtest.reshape(-1,1)
      self.model.fit(self.Xtrain, self.Ytrain)

  # Prints a classification report which shows the performance of the model
  # in relation to the test and train samples randomly selected above 
  # If intrested in seeing it , uncomment the line in the test cases
  def getClassificationReport(self):
      self.Xtest2 = self.model.predict(self.Xtest)
      return print(classification_report(self.Ytest,self.Xtest2,zero_division=1))

  def predictMyTiredness (self,encodedD):
      #print(encodedD)

      # The extra brackets is trasform data from 1D to 2D 
      # as predict does not support 1D

      return self.model.predict([encodedD])
# to increase estimators in case data set grew exponentially
# and num of estimators needs to be increased 
  def increaseEstimators(self):
    self.n += 1

# Helper f(x) to encode the user reponse to the mode the model was trained on 
def encodeUserDinner(response):
  if response == 'Yes':
    return [1]
  elif response == 'No':
    return [0]


# myModel2 = PredictTirednessBasedOnDinner()
# myModel2.encode()
# myModel2.buildModel()
# myModel2.getClassificationReport()
# print(myModel2.predictMyTiredness(encodeUserDinner('No')))

# MODEL 3 : PREDICT TIREDNESS BASED ON EXCERISE 
class PredictTirednessBasedOnExcersie (object):

  # Conatins the model and the importation of Data set
  def __init__(self):
  
    self.n = 50
    self.model = RandomForestClassifier(n_estimators = self.n)
    self.sleepData = pd.read_csv('HrsDataSet.csv',sep = ',')

# Preprocessing is done to alter the state of the data to fit the model 
# No = 0 ,  Yes = 1
  def encode(self):
    preProcess = preprocessing.LabelEncoder()
    self.encodedDinner = preProcess.fit_transform(self.sleepData['Excersie'])
    #print(self.encodedDinner)

# the construction of model is mainly done here
  def buildModel(self):

      target = self.sleepData['Tired ']
      data = self.encodedDinner

      if len(self.encodedDinner)> 1*pow(10,6):
        self.model.warm_start = True

      self.Xtrain,self.Xtest,self.Ytrain,self.Ytest = train_test_split(data,target,test_size = 0.30 )
      self.Xtrain = self.Xtrain.reshape(-1,1) 
      self.Xtest = self.Xtest.reshape(-1,1)
      self.model.fit(self.Xtrain, self.Ytrain)

  # Prints a classification report which shows the performance of the model
  # in relation to the test and train samples randomly selected above 
  # If intrested in seeing it , uncomment the line in the test cases
  def getClassificationReport(self):
      self.Xtest2 = self.model.predict(self.Xtest)
      return str(classification_report(self.Ytest,self.Xtest2,zero_division=1))

  def predictMyTiredness (self,encodedE):
      # print(encodedD)

      # The extra brackets is trasform data from 1D to 2D 
      # as predict does not support 1D

      return self.model.predict([encodedE])

  def increaseEstimators(self):
    self.n += 1

# Helper f(x) to encode the user reponse to the mode the model was trained on 
def encodeUserExcersise(response):
  if response == 'Yes':
    return [1]
  elif response == 'No':
    return [0]


# myModel3 = PredictTirednessBasedOnExcersie()
# myModel3.encode()
# myModel3.buildModel()
# myModel3.getClassificationReport()
# print(myModel3.predictMyTiredness(encodeUserExcersise('Yes')))

# Function that calls both models and calulate avgTiredness scale
# Based on outputs of both models to create an input for Model 4
def calculateAVGTiredness(rawDinnerResponse,rawExcersieResponse):
# calling excersie model
  myModel1 = PredictTirednessBasedOnExcersie()
  myModel1.encode()
  myModel1.buildModel()
  outcomeOne =  myModel1.predictMyTiredness(encodeUserExcersise(rawExcersieResponse))

# Calling the Dinner model
  myModel2 = PredictTirednessBasedOnDinner()
  myModel2.encode()
  myModel2.buildModel()
  outcomeTwo = myModel2.predictMyTiredness(encodeUserDinner(rawDinnerResponse))

  avergeTir = outcomeOne + outcomeTwo // 2 
  return avergeTir


# print(calculateAVGTiredness('Yes','Yes'))
# print(calculateAVGTiredness('No','No'))
# print(calculateAVGTiredness('Yes','No'))
# print(calculateAVGTiredness('No','Yes'))

# MODEL 4 : ESTIMATE QUALITY OF SLEEP BASED ON TIREDNESS
class PredictSleepQualit(object):
    
    # In opposition to other 3 models , this model uses
    # KKNeighborsClassifier because its sensitive to outliers which can be useful with
    # Tiredness scale
  def  __init__(self):
    self.model = KNeighborsClassifier()
    self.sleepData = pd.read_csv('HrsDataSet.csv',sep = ',')

  def encode(self):
    preProcess = preprocessing.LabelEncoder()
    self.encodedDinner = preProcess.fit_transform(self.sleepData['Tired '])

# the construction of model is mainly done here
  def buildModel(self):

      target = self.sleepData['Enough']
      data = self.encodedDinner

      if len(self.encodedDinner)> 1*pow(10,6):
        self.model.warm_start = True

      self.Xtrain,self.Xtest,self.Ytrain,self.Ytest = train_test_split(data,target,test_size = 0.30 )
      self.Xtrain = self.Xtrain.reshape(-1,1) 
      self.Xtest = self.Xtest.reshape(-1,1)
      self.model.fit(self.Xtrain, self.Ytrain)

  # Prints a classification report which shows the performance of the model
  # in relation to the test and train samples randomly selected above 
  # If intrested in seeing it , uncomment the line in the test cases
  def getClassificationReport(self):
      self.Xtest2 = self.model.predict(self.Xtest)
      return classification_report(self.Ytest,self.Xtest2,zero_division=1)

  def PredictQuality (self,encodedT):
      # print(encodedT)

      # The extra brackets is trasform data from 1D to 2D 
      # as predict does not support 1D

      return self.model.predict([encodedT])

  def increaseEstimators(self):
    self.n += 1

# Final and main function :
# calls all four models directly and indirectly and produce the
# Overall Quality of sleep

def findFinalQuality (hrsSlept,breakfastEaten,screenTime):
    myModel = PredictQualityHrs()
    myModel.encode()
    myModel. buildModel()
    prediction1 = myModel.predictIsItEnough([hrsSlept])
    
    avgTiredness = calculateAVGTiredness(breakfastEaten,screenTime) 
    myModel2 = PredictSleepQualit()
    myModel2.encode()
    myModel2.buildModel()
    prediction2 = myModel2.PredictQuality(avgTiredness)
#     print(hrsSlept,prediction1,prediction2)

    if prediction1 == 'Yes':
        if prediction2 == 'Yes':
            return 'Good'
        else:
            return 'Averge'
    elif prediction1 == 'No':
        if prediction2 == 'Yes':
            return 'Averge'
        else:
            return 'Poor'

# for i in range (10):
#      print(findFinalQuality(i,'Yes','Yes'))
#      print(findFinalQuality(i,'No','No'))

# Function to call in GUI to show user the prediction of the model

def toShowUser(rawDinnerResponse,rawExcersieResponse):
    
  myModel1 = PredictTirednessBasedOnExcersie()
  myModel1.encode()
  myModel1.buildModel()
  outcomeOne =  myModel1.predictMyTiredness(encodeUserExcersise(rawExcersieResponse))

  myModel2 = PredictTirednessBasedOnDinner()
  myModel2.encode()
  myModel2.buildModel()
  outcomeTwo = myModel2.predictMyTiredness(encodeUserDinner(rawDinnerResponse))
  avergeTir = outcomeOne + outcomeTwo // 2
  
  if outcomeOne < outcomeTwo:
      highest ,scale = 'Dinner',outcomeTwo
      
  else:
      highest ,scale = 'Excersie',outcomeOne
      
  return highest ,int(scale),avergeTir

