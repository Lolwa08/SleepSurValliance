a = 1
ownerName = 'Bobbie'



# LIBRARIES NEEDED :

import basic_graphics

import matplotlib.pyplot as plt

import ImageWriter as im

from cmu_112_graphics import *

import ast







# Implemented Object Oriented Programming to produce the report and its pages

class DrawReport(object):

    # F(x) to draw the first page

    def reportPgOne(self,app,canvas):

        canvas.create_rectangle(0,0,app.width,app.height,fill = 'Purple')

        canvas.create_text(app.width//2,app.height//2, text = 'SSV',font = f'{app.font} {app.textSize*2}')

        canvas.create_text(app.width//4,app.height*0.6, text = 'by Sleep SurVeillance',font = f'{app.font} {app.textSize//2} italic',anchor = 'sw')

        canvas.create_text(app.width*0.30,app.height*0.65, text = f'{ownerName} Sleep Report',font = f'{app.font} {app.textSize//2} italic',anchor = 'sw')

        canvas.create_text(app.width*3//4,app.height*0.9,text = "Press 'Enter' to move to the next page ",anchor = 'n' ,font = 'italic')



    # F(x) to draw the second page and its graphs

    def struMy_Report(self,app,canvas,L1,L2,L3):

        canvas.create_rectangle(0,0,app.width,app.height,fill = 'Purple')

        canvas.create_text(app.width//2,app.height//20, text = 'SSV',font = f'{app.font} {app.textSize}')

        canvas.create_text(app.width//2,app.height//10, text = 'by Sleep SurVeillance',font = f'{app.font} {app.textSize//4} italic',anchor = 'sw')

        canvas.create_line(0,app.height//9,app.width,app.height//9)



        # AVG Per day : SCREEN TIME

        canvas.create_text(app.width*2//3,app.height*3//4,text = 'An Averge of \nHrs of screentime \nbefore bed \nper day',font = f'{app.font} {app.textSize//4}')

        canvas.create_text(app.width*3//4,app.height*3//4,text = f' {app.phoneAVG}',font =f'{app.font} {app.textSize*2}' )



        # Dinner TABEL:

        canvas.create_rectangle(app.margin,app.height*0.6,app.width//2,app.height-app.margin//2,fill = 'white',width=0)

        for i in range (8):

            canvas.create_line(app.margin,app.height*0.6 + i*app.increments,app.width//2,app.height*0.6+i*app.increments)

        canvas.create_line( (app.margin+app.width//2)//2, app.height*0.6, (app.margin+app.width//2)//2, app.height-app.margin//2)

        canvas.create_text(app.margin+app.width*0.22,app.height*0.59,text = 'Dinner Eaten  ',font =f'{app.font} {app.textSize//2}')

        

        for i in range (7):

            canvas.create_text(app.margin+app.width//8, (app.height*0.62)+i*app.increments,text = f'{app.days[i]}')

            canvas.create_text(app.margin+app.width//4, (app.height*0.62)+i*app.increments,text = f'{app.dinner[i]}')

    

    # F(x) to draw the next page  

    def nextPage(self,app,canvas):

         canvas.create_rectangle(0,0,app.width,app.height,fill = 'Purple')

         canvas.create_text(app.width//2,app.height//20, text = 'SSV',font = f'{app.font} {app.textSize}')

         canvas.create_text(app.width//2,app.height//10, text = 'by Sleep SurVeillance',font = f'{app.font} {app.textSize//4} italic',anchor = 'sw')

         canvas.create_line(0,app.height//9,app.width,app.height//9)

         # Exce TABEL:

         canvas.create_rectangle(app.margin,app.height*0.6,app.width//2,app.height-app.margin//2,fill = 'white',width=0)

         for i in range (8):

            canvas.create_line(app.margin,app.height*0.6 + i*app.increments,app.width//2,app.height*0.6+i*app.increments)

            canvas.create_line( (app.margin+app.width//2)//2, app.height*0.6, (app.margin+app.width//2)//2, app.height-app.margin//2)

            canvas.create_text(app.margin+app.width*0.22,app.height*0.59,text = 'Exercise Done  ',font =f'{app.font} {app.textSize//2}')

         for i in range (7):

            canvas.create_text(app.margin+app.width//8, (app.height*0.62)+i*app.increments,text = f'{app.days[i]}')

            canvas.create_text(app.margin+app.width//4, (app.height*0.62)+i*app.increments,text = f'{app.exercise[i]}')



            

def appStarted(app):

    analyseUserFile(app)

    drawGraphs(app)

    

    





#  Code from : cs.cmu.edu/~112/notes/notes-strings.html#basicFileIO

def readFile(path):

    with open(path, "rt") as f:

        return f.read()

                    

    

# Function that takes txt files and formate the data to be used to draw graphs

def analyseUserFile(app):

    app.curSlide =  0 

#     print('OWNER',ownerName)

    app.curSlide = -1

    app.days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']

    app.daysOfWeek = 'Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday'

    app.margin = min(app.height,app.width)//10

    app.barsW =  app.width - 2*app.margin // 7 

    app.HrsOfWeek = [8,9,3,2,5,2,1]

    app.dinner  = ['Y','Y','Y','Y','Y','Y','Y']

    app.exercise  = ['Y','Y','Y','Y','Y','Y','Y']

    app.Quality = ['G','B','G','B','A','G','A']

    app.phoneDuraWeek = [0,0,0,0,0,0,0]

    app.Report = DrawReport()

    app.increments = ((app.height - app.margin ) - app.height//2 )//8 

    app.font = 'Arial'

    app.projectName = 'SSV'

    app.userData = readFile(f'{ownerName}.txt')

    app.userData = app.userData.replace(' ','')

    app.userData = app.userData.replace('\n','')

    app.userData = app.userData.split(',')

    app.newData = []

    start = 0



    # Formatting Data in files 

    for i in range (1,len(app.userData)):

        element = app.userData[i]

        if element in app.daysOfWeek:

            app.newData.append(app.userData[start:i])

            start = i

            

    #DATA FORMAT : Day ,Hr,Dinner,Exercise,Quality,PTime

    for i in range (len(app.newData)):

        element = app.newData[i]

        print(element)

        app.HrsOfWeek[i] = int(element[1])

        app.dinner[i] = element[2][0]

        app.exercise[i] = element[3][0]

        app.Quality[i] = element[4][0]

        app.phoneDuraWeek[i] = int(element[5])

        app.textSize = min(app.width,app.height)//21

        

    app.curSlide += 1

    

def drawGraphs(app):

    

    app.phoneAVG = sum(app.phoneDuraWeek)//7

    label = 'Sleep Hrs Per Day'

    xAxis = app.days

    yAxis = app.HrsOfWeek

    #Producing bar graph using matplotlib    

    plt.bar(xAxis,yAxis,color = 'purple')

    plt.title(label)

    plt.ylabel('Hours')

    plt.xlabel('Days')

    plt.savefig('weekBarGraph.png')

    

    # From CMU.Pittsburg Lecture Notes

    app.image = app.loadImage('weekBarGraph.png')

    app.image1 = app.scaleImage(app.image,3/4)

    

    plt.clf() # clearing image to draw next graph

    

    label2 = 'Overall Quality Of Sleep Per Day'

    xAxis2= app.days

    yAxis2 = app.Quality

    

    #Producing line graph using matplotlib    

    plt.plot(xAxis2,yAxis2,color = 'blue')

    plt.title(label2)

    plt.ylabel('Quality')

    plt.xlabel('Days')

    plt.savefig('QGraph.png')

    app.image = app.loadImage('QGraph.png')

    app.image2 = app.scaleImage(app.image,3/4)

    

    plt.clf()

    label3 = 'Screen Time before bed '

    xAxis3= app.days

    yAxis3 = app.phoneDuraWeek

    

    #Producing line graph 2 using matplotlib    

    plt.plot(xAxis3,yAxis3,color = 'purple')

    plt.ylabel('Hours')

    plt.xlabel('Days')

    plt.title(label3)

#     plt.show()

    plt.savefig('STGraph.png')

    app.image = app.loadImage('STGraph.png')

    app.image3 = app.scaleImage(app.image,3/4)

    

    

def keyPressed (app,event):

    if event.key == 'Enter':

        app.curSlide += 1

    elif event.key == 'Backspace':

        if app.curSlide>0:

            app.curSlide -= 1

            

            

            



def redrawAll(app,canvas):

    

    if app.curSlide== 0 : app.Report.reportPgOne(app,canvas)

    if app.curSlide == 1:

        

        #Calling OOP for basic report structure

        app.Report.struMy_Report(app,canvas,app.HrsOfWeek,app.dinner,app.phoneDuraWeek)

        # Uploading image of bar graph

        canvas.create_image(app.width//2,app.height*0.35, image = ImageTk.PhotoImage(app.image1))

        

    elif app.curSlide == 2:

#         app.Report.nextPage(app,canvas)

         canvas.create_rectangle(0,0,app.width,app.height,fill = 'Purple')

         canvas.create_text(app.width//2,app.height//20, text = 'SSV',font = f'{app.font} {app.textSize}')

         canvas.create_text(app.width//2,app.height//10, text = 'by Sleep SurVeillance',font = f'{app.font} {app.textSize//4} italic',anchor = 'sw')

         canvas.create_line(0,app.height//9,app.width,app.height//9)

         canvas.create_image(app.width//2,app.height*0.35, image = ImageTk.PhotoImage(app.image2))

         canvas.create_image(app.width//2,app.height*0.75, image = ImageTk.PhotoImage(app.image3))

         

    elif app.curSlide == 3:

        canvas.create_text(app.width//2,app.height//2,text = 'New feature Coming Soon... ')

        







runApp(width=700, height=900)


