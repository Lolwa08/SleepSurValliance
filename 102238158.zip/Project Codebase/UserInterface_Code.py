# ************************************************************************************************
# BULB IMAGE FROM : https://www.google.com/search?q=light+bulb+png&rlz=1C1GCEA_enQA979QA979&source=
# lnms&tbm=isch&sa=X&ved=2ahUKEwiDuO6J37P0AhXOjqQKHf6qBtIQ_AUoAXoECAEQAw&biw=1280&bih=609&dpr=1.5#imgrc=3HF-Xn2psfBvdM



# *** LIBRARIES NEEDED ***
import random
import pandas as pd
import basic_graphics
import matplotlib.pyplot as plt
import ImageWriter as im
from cmu_112_graphics import *
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from Machine_LearningModels_V3 import findFinalQuality,toShowUser

#Implemented OOP to make it easier to navigate drawing the slides
# f(x) with names S1,S2,S3...etc all represent functions to draw different things for diff slides
class UserInterface(object):
    
    def __init__ (self,c1=(204,75,207),c2=(186,63,207),c3= (164,81,204)):
        self.c1= c1
        self.c2 = c2
        self.c3 = c3
        
    # Color set as a parameter to enable drawing different slides with decrasing stauration of the color purple
    def dOfTheWeek(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        # write f(x) to allow user to input day instead of keeping track of it 
        canvas.create_text(app.width*0.45,app.height//2,text = """Hello ! \n Please select a number to log today's day \
\nSo the data can be saved accordingly 
        \n Choose the number that \n corresponds to the suitable day :
        \n Sunday:0 \n Monday:1 \n Tuesday:2 \n Wednesday:3 \n Thursday:4 \n Friday:5 \n Saturday:6""",
                           font = f"{app.font} {app.textSize//5}" )
        canvas.create_text(app.width*0.50,app.height*0.62,text = f"""{app.dayStatus[0]}\n{app.dayStatus[1]}\n\
{app.dayStatus[2]}\n{app.dayStatus[3]}\
\n{app.dayStatus[4]}\n{app.dayStatus[5]}\n{app.dayStatus[6]}""" ,font =  f"{app.font} {app.textSize//5} italic")

    
    def drawS1(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_image(app.width//2,app.height//2, image = ImageTk.PhotoImage(app.image0))
        canvas.create_text(app.width//2,app.height*0.19, text = app.projectName,font = f'{app.font} \
{int(app.textSize+app.textSize*0.1)}')
        canvas.create_text(app.width//2,app.height*0.24, text = 'Sleep SurVeillance',font = f'{app.font} \
{app.textSize//2} ',anchor = 'n')
        canvas.create_rectangle(app.width*0.5,app.height*0.80,app.width*0.8,app.height*0.95,fill='white')
        canvas.create_text(app.width*0.65,app.height*0.85,text = 'Ready?',font = f'{app.font} {app.textSize//2}')
        canvas.create_text(app.width*0.15,app.height*0.5,text = f'{app.userSurprise}',font = f'{app.font} \
{int(app.textSize*0.2)} italic')


    def drawS1V2(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4, text = app.projectName,font = f'{app.font} {app.textSize}')
        canvas.create_rectangle(app.width*0.05,app.height*0.5,app.width*0.45,app.height*0.65,fill = rgbString(255,206,251),width=0)
        canvas.create_rectangle(app.width*0.10,app.height*0.55,app.width*0.48,app.height*0.7 , fill = 'white',width = 0)
        canvas.create_text(app.width*0.19,app.height*0.55,text = 'T I P',font = f'{app.font} {app.textSize//4}')
        canvas.create_image(app.width*0.1,app.height*0.55,image = ImageTk.PhotoImage(app.bulbImg))
        canvas.create_text(app.width*0.33,app.height*0.65,text = """If you forgot under which instance\nof your \
name did you log your previous \ninfo click here for help !""", font = f'{app.font}')
        canvas.create_text(app.width*0.55,app.height*0.85,text = f'recent Logs:{app.userNeedsHelp}',font = f'{app.font}')
        
        canvas.create_text(app.width//2,app.height//3, text = 'Sleep SurVeillance',font = f'{app.font} {app.textSize//2} italic',anchor = 'n')
        canvas.create_rectangle(app.width*0.5,app.height*0.5,app.width*0.90,app.height*0.65,fill='white')
        canvas.create_text(app.width*0.65,int(app.height*0.55),text = 'Please Enter Your name:',font = f'{app.font} {app.textSize//5}')
        canvas.create_text(app.width*0.7,int(app.height*0.60),text = f"{app.ownerName}",font = f'{app.font} {app.textSize//4}')
        
    
    def drawS2(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//4,app.height//2,text = 'First of all \n How long did you \n sleep last night?',
                           font = f'{app.font} {min(app.width,app.height)//50}')
        canvas.create_rectangle(app.width//2,app.height//2,app.width*3//4,app.height*6//10,fill='white')
        canvas.create_text(app.width//2,app.height*4//10, text = 'Hours:',fill = 'black',font = f'{app.font} {min(app.width,app.height)//50}')
        canvas.create_text(app.width*3//4,app.height*6//10,text = app.HrSleptDAY,font = f'{app.font} {app.textSize//2}',anchor = 'se')
    
    def drawS3(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4, text = 'Did you eat Dinner last night?',fill = 'black',\
                           font = f'{app.font} {min(app.width,app.height)//50}')
        canvas.create_rectangle(app.width//4,app.height//2,app.width//2,app.height*3//4,fill='white')
        canvas.create_text(app.width//3,app.height*2//3,text= 'Yes',font = f'{app.font} {app.textSize//2}',anchor = 'sw')
        canvas.create_rectangle(app.width//2,app.height//2,app.width*3//4,app.height*3//4,fill='white')
        canvas.create_text(app.width*2//3,app.height*2//3,text= 'No',font = f'{app.font} {app.textSize//2}',anchor = 'se')
    
    def drawS4(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4, text = 'Did you eat Exercise last night?',fill = 'black',\
                           font = f'{app.font} {min(app.width,app.height)//50}')
        canvas.create_rectangle(app.width//4,app.height//2,app.width//2,app.height*3//4,fill='white')
        canvas.create_text(app.width//3,app.height*2//3,text= 'Yes',font = f'{app.font} {app.textSize//2}',anchor = 'sw')
        canvas.create_rectangle(app.width//2,app.height//2,app.width*3//4,app.height*3//4,fill='white')
        canvas.create_text(app.width*2//3,app.height*2//3,text= 'No',font = f'{app.font} {app.textSize//2}',anchor = 'se')

    def drawS5(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//2,text = 'LOADING...', font = f"{app.font} {app.textSize//2} bold" )
        canvas.create_text(app.x,app.y, text = 'Calculating Quality of Sleep..',fill = 'black',\
                           font = f'{app.font} {min(app.width,app.height)//50}')
        
        
    def drawS6(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4,text = "Based on our Machine Learning Model \n and your log for \
the day \n Your estimated Quality of sleep \n  based on your habits "
                           , font = f"{app.font} {app.textSize//4} bold")
        canvas.create_text(app.width//2,app.height//2, text = f'{app.FFSQ}',font = f'{app.font} {min(app.width,app.height)//5}' )
        canvas.create_text(app.width//2,app.height*3//4,text = app.qualityComment[app.FFSQ],\
                           font = f'{app.font} {min(app.width,app.height)//50}')
        
    def drawS7(self,app,canvas,color):
        # ACCURACY CHECK
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4,text = "Was the prediction Accurate?", font = f'{app.font} {app.textSize//2}')
        canvas.create_rectangle(app.width//4,app.height//2,app.width//2,app.height*3//4,fill='white')
        canvas.create_text(app.width//3,app.height*2//3,text= 'Yes',font = f'{app.font} {app.textSize//2}',anchor = 'sw')
        canvas.create_rectangle(app.width//2,app.height//2,app.width*3//4,app.height*3//4,fill='white')
        canvas.create_text(app.width*2//3,app.height*2//3,text= 'No',font = f'{app.font} {app.textSize//2}',anchor = 'se')
    
    def drawS8(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//8,text = "Help us Improve our model , \n what was the quality of your sleep?",
                           font = f'{app.font} {app.textSize//4} italic bold')
        canvas.create_rectangle(0,app.height//6,app.width,app.height*4//9,fill = rgbString(self.c1[0],self.c1[1],self.c1[2]))
        canvas.create_text(app.width//2,app.height//4,text = 'Poor',font = f'{app.font} {app.textSize} italic bold',anchor = 'n')
        canvas.create_rectangle(0,app.height*4//9,app.width,app.height*13//18,fill =  rgbString(self.c2[0],self.c2[1],self.c2[2]))
        canvas.create_text(app.width//2,app.height//2,text = 'Averge',font = f'{app.font} {app.textSize} italic bold',anchor = 'n')
        canvas.create_rectangle(0,app.height*13//18,app.width,app.height,fill =  rgbString(self.c3[0],self.c3[1],self.c3[2]))
        canvas.create_text(app.width//2,app.height*3//4,text = 'Good',font = f'{app.font} {app.textSize} italic bold',anchor = 'n')
        
    def drawS9(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4,text = " Thank you for visitng today \n What would you like to do next ?",
                           font = f"{app.font} {app.textSize//2}")
        canvas.create_rectangle(0,app.height//2,app.width//3,app.height*3//4,fill = 'white')
        canvas.create_rectangle(app.width//3,app.height//2,app.width*3//4,app.height*3//4,fill = rgbString(213,141,200))
        canvas.create_rectangle(app.width*3//4,app.height//2,app.width,app.height*3//4,fill = 'white')
        canvas.create_text(app.width*0.15,app.height*6//10,text = 'Quality \n  Clarification ',font = f'{app.font} {app.textSize//5}')
        canvas.create_text(app.width*5//10,app.height*6//10,text = ' Get Sleep Report \n  (only avalible after 7 Days log )',
                           font = f'{app.font} {app.textSize//5} italic')
        canvas.create_text(app.width*8//10,app.height*6//10,text = 'Logout',font = f'{app.font} {app.textSize//5}')


    def drawS10(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4, text = 'Rate How Tired you Are out of 5: \n \
(5 indicates exhuastion , 1 not tired at all)',fill = 'black',
                           font = f'{app.font} {min(app.width,app.height)//50}')
        canvas.create_rectangle(app.width//4,app.height//2,app.width*3//4,app.height*6//10,fill='white')
        canvas.create_text(app.width//2,app.height*5.5//10,text = app.tirednessScale ,font = f'{app.font} {app.textSize//2}')
        
    def draw10V2(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width*0.5,app.height*0.10,text = "Stastics",font = f'{app.font} {app.textSize}')
        canvas.create_text(app.width*0.5,app.height*0.40,text = f"""Our Machine Learning model \n
Estimated Tiredness Scale based on Excersie and Dinner as {app.predictedBtModel[1]}
your overall Sleep Quality was downgraded due to your {app.predictedBtModel[0]} habits
which you should invest in improving""",font = f'{app.font} {int(app.textSize//4)}')
        
        
        
    
    def drawS11(self,app,canvas,color):
        
        canvas.create_image(app.width//2,app.height//2, image = ImageTk.PhotoImage(app.image))
        canvas.create_text(app.width*0.35,app.height*0.55,text = " Thank you for visitng today! \n See you tomorrow...",
                           font = f'{app.font} {app.textSize//4} bold italic ',fill = 'white')
    
    def drawS12(self,app,canvas,color):
        canvas.create_rectangle(0,0,app.width,app.height,fill = color)
        canvas.create_text(app.width//2,app.height//4, text = 'How long did you use your phone \n before bed?',fill = 'black',
                           font = f'{app.font} {min(app.width,app.height)//50}')
        canvas.create_rectangle(app.width//4,app.height//2,app.width*3//4,app.height*6//10,fill='white')
        canvas.create_text(app.width//2,app.height*5.5//10,text = app.phoneDura ,font = f'{app.font} {app.textSize//2}')
        

# Helper f(x) from class Notes to convert RGB to str
def rgbString(red, green, blue):
     return "#%02x%02x%02x" % (red, green, blue)

# AppStarted contains all variables needed
# for the animation of the Graphical User Interface 
def appStarted(app):
    app.timer = 0
    app.font = 'Century'
    app.projectName = 'SSV'
    app.textSize = min(app.width,app.height)//12
    app.systemStarted = False
    app.drawNext = False
    app.userDone = False
    app.main = UserInterface()
    app.curSlide = 0
    app.userReady = False
    #In order of ->   S M T W T F S
    app.HrsOfWeek = [0,0,0,0,0,0,0]
    app.dinner  = ['No','No','No','No','No','No','No']
    app.exercise  = ['No','No','No','No','No','No','No']
    app.Quality = ['G','B','G','B','A','G','A']
    app.daysOfWeek = 'Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday'
    app.phoneDuraWeek = [0,0,0,0,0,0,0]
    app.sevenLogs = False
    app.phoneDuraWeek = [2,2,2,2,2,2,2]
    app.dayStatus = ['Not Logeed','Not Logeed','Not Logeed','Not Logeed','Not Logeed','Not Logeed','Not Logeed']
    
    app.timerDelay = 1000
    app.day = 'Sunday'
    app.days = {0:'Sunday',1:'Monday',2:'Tuesday',3:'Wednesday',4:'Thursday',5:'Friday',6:'Saturday'}
    app.qualityComment = {'Averge':'Not the best nights of your life \n but also not the worst',
                          'Good':'Wish everynight was like that','Poor':"Hoping Tomorrow isn't \n like this night"}
    app.dayKey = None
    app.phoneDura =""
    app.HrSleptDAY = ""
    app.preidAccuracy = True
    app.ownerName = ''
    app.nameSaved = False
    app.ThankYouPg = False
    app.users = {}
    app.image0 = app.loadImage("eyes.png")
    app.slideOAnimationY = random.randint(0,app.height*0.95)
    app.tirednessScale = 0
    app.predictedBtModel = ""
    app.userSurprise = ''
    app.i = 0
    app.bulbImg = app.loadImage("lBulb.png")
    app.bulbImg = app.scaleImage(app.bulbImg, 1/2)
    app.userNeedsHelp = ''
    app.daysStatus = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

# To control the randomness of the text in slide5
def timerFired(app):
    # This mini series of if statments handles the animation of welcoming slide
    if app.timer%2 == 0:
        
        app.image0 = app.loadImage("eyes1.png")
        app.userSurprise=''
    elif app.timer%3 == 0:
        
        app.image0 = app.loadImage("eyes.png")
        app.userSurprise=''
    else:
        
        app.image0 = app.loadImage("eyes2.png")
        app.userSurprise = f'Did you know that \n{getRecentUser(app)} started using \n     SSV too!'
   
    app.timer += 1 
    app.x = random.randint(0,app.width)
    app.y = random.randint(0,app.height)
        
    if app.timer%15 == 0 and app.curSlide == 5 :
        app.curSlide += 1
        if len( app.HrSleptDAY )== 0 :
            app.HrSleptDAY = '7'
        app.FFSQ = findFinalQuality(int(app.HrSleptDAY),app.dinner[app.dayKey],app.exercise[app.dayKey])
    
    if app.curSlide ==5:
        app.predictedBtModel = toShowUser(app.dinner[app.dayKey],app.exercise[app.dayKey])
        
    
 
#KeyPressed is mainly used to allow the user to input numbers with more than one value
#For example ,this allows the use to enter 10 for hrs of sleep
#KeyPressed is also used to set defeault values if user chose not to input certain vals
#such as sleep hrs or phone time
        
def keyPressed(app, event):
    
    if app.userReady == True and app.curSlide == 0 :
        if app.nameSaved == False:
            if event.key == 'Enter':
                checkStatusOfLog(app)
                app.nameSaved = True
                return 
            elif event.key == 'Backspace':
                app.ownerName = app.ownerName[:-1]
            else:
                app.ownerName += str(event.key)

    if app.nameSaved == True and app.curSlide == 0:
        if event.key in '0123456':
            app.dayKey = int(event.key)
            app.day = app.days[int(event.key)]
            app.systemStarted = True
            app.curSlide += 1
            
        elif app.curSlide != 0 :
            app.curSlide += 1
                    
    elif app.systemStarted == True:
        if app.curSlide == 1:
            if event.key in '0123456789' and len(app.HrSleptDAY) < 2 :
                app.HrSleptDAY += str(event.key)
            elif event.key == 'Backspace':
                app.HrSleptDAY = app.HrSleptDAY[:-1]
            
        if event.key == 'Enter':
            app.curSlide += 1
            
        if app.curSlide == 4:
            if len(app.phoneDura) <= 2 and event.key in '0123456789':
                app.phoneDura += str(event.key)
            elif event.key == 'Backspace':
                app.phoneDura = app.phoneDura[:-1]
            if event.key == 'Enter' and len(app.phoneDura) == 0 :
                app.phoneDura = '2'
            
        elif app.curSlide == 10:
            if str(event.key) in '012345':
                app.tirednessScale = int(event.key)
            
        elif event.key == 'Enter' and app.curSlide == 12:
            app.curSlide = 9

                
                
            
# Mouse pressed is used to trigger next slides for some slides that require 'mouse clicks'
# to trigger other commands or slides to show 
def mousePressed(app,event):
    
        if app.drawNext == False and app.curSlide == 0 :
            if app.width*0.5 < event.x <app.width*0.8  and app.height*0.8<event.y <app.height*0.95:
                app.userReady = True
                app.drawNext = True
                
        if app.userReady ==  True and app.curSlide == 0:
            if app.width*0.10< event.x < app.width*0.48 :
                if app.height*0.5<event.y < app.height*0.7:
                    app.userNeedsHelp = getUsers(app)

                
        elif app.curSlide == 2:
            if app.height//2 < event.y < app.height*3//4:
                if event.x < app.width//2:
                    app.dinner[app.dayKey] = 'Yes'
                else:
                    app.dinner[app.dayKey] = 'No'
            app.curSlide += 1
            
        elif app.curSlide == 3:
            if app.height//2 < event.y < app.height*3//4:
                if event.x < app.width//2:
                    app.exercise[app.dayKey] = 'Yes'
                else:
                    app.exercise[app.dayKey] = 'No'
            app.curSlide += 1
        
            
        elif app.curSlide == 7:          
             if app.height//2 < event.y < app.height*3//4:
                if event.x < app.width//2:
                    app.preidAccuracy = True
                    app.curSlide +=1 
                else:
                    app.preidAccuracy = False
                app.curSlide += 1
                
        elif app.curSlide == 8 and app.preidAccuracy == False:
            if app.height//6<event.y <app.height*4//9:
                app.FFSQ = 'Poor'

            elif app.height*4//9 < event.y < app.height*13//18 :
                app.FFSQ = 'Averge'

            elif app.height*13//18 < event.y < app.height:
                app.FFSQ = 'Good'
                
            app.curSlide += 1

                
        elif app.curSlide == 9:
            saveDataForModel(app)
            if  app.height//2 < event.y <app.height*3//4:
                if app.width*3//4 <event.x <app.width: # User wants to Log out
                    app.systemStarted = False
                    app.userReady = False
                    app.ThankYouPg =True
                    saveData(app)
                    app.image = app.loadImage("ThankYouPic.png")
                    app.curSlide = 20
                    
                elif app.width//4<event.x<app.width*5//10:
                    # Checks if user logged all 7 days , else does nothing
                    saveData(app)
                    checkStatusOfLog(app)
                    for element in app.dayStatus:
                        if element == 'Not Logged':return
                    editSleepReportFile(app.ownerName)
                    import SleepReport
                elif 0 < event.x < app.width//3 and app.height//2<event.y<app.height*3//4:
                    app.curSlide += 1
                    
     
        

#If user logs out : SAVE DATA 
#Use me to save user data
#into here to use it for machine learning model
#Base Code from : cs.cmu.edu/~112/notes/notes-strings.html#basicFileIO
def readFile(path):
        with open(path, "rt") as f:
            return f.read()

def writeFile(path, contents):
        with open(path, 'a') as f:
            f.write(contents)
            
# Function that gets the newest user of the system
def getRecentUser(app):
    users = readFile('SSVusers.txt')
    data = ""
    for element in users:
        data += element
    data = data.split('\n')
    return data[-1]
# This function is different as it returns all
# The users of the System
def getUsers(app):
    users = readFile('SSVusers.txt')
    data = ""
    for element in users:
        data += element
    data = data.split('\n')
    return data

# encodes Tiredness Scale into common format
# for the machine learning Data set
def analyseEnough (app):
    if int(app.tirednessScale) < 3:
        return 'No'
    else:
        return 'Yes'
    
# Save Data for machine learning model
# FORMAT :Hours,Enough,Dinner,Excersi,Tired
def saveDataForModel(app):
    if app.tirednessScale != 0:
        mlContent = f"""\n{app.HrSleptDAY}	{analyseEnough(app)}	{app.dinner[app.dayKey]}	{app.exercise[app.dayKey]}	{app.tirednessScale}"""
        writeFile('newDataSetML.txt',mlContent)
    else:
        app.tirednessScale = app.predictedBtModel[2]
        app.tirednessScale = str(app.tirednessScale)
        app.tirednessScale = app.tirednessScale.replace(']','')
        app.tirednessScale = app.tirednessScale.replace('[','')
        app.tirednessScale = int(app.tirednessScale)

        mlContent = f"""\n{app.HrSleptDAY}	{analyseEnough(app)}	{app.dinner[app.dayKey]}	{app.exercise[app.dayKey]}	{app.tirednessScale}"""
        writeFile('newDataSetML.txt',mlContent)
    
    
# saves data before log out in txt file
def saveData(app):
    users = readFile('SSVusers.txt')
    if app.ownerName in users :
        contentsToWrite = f" \n    {app.day},{app.HrSleptDAY},{app.dinner[app.dayKey]},\
{app.exercise[app.dayKey]},{app.FFSQ},{app.phoneDura},"
        writeFile(f"{app.ownerName}.txt", contentsToWrite)
    else:
        writeFile('SSVusers.txt', f'\n{app.ownerName}')
        contentsToWrite =f" \n    {app.day},{app.HrSleptDAY},{app.dinner[app.dayKey]},\
{app.exercise[app.dayKey]},{app.FFSQ},{app.phoneDura},"
        writeFile(f"{app.ownerName}.txt", contentsToWrite)

# Function to edit the owner name in the sleep report file so that the
# the report is generated based on specefic user data 
def editSleepReportFile(name):
    f = open("SleepReport.py",'r+')
    for i in range (1):
        f.readline()
    f.seek(f.tell())
    f.write(f'"{name}"')
    f.close()
        
# Version2 of writing files , where it append to exsiting file instead
# of writing it from scratch 
def writeFileVer2(path):
        with open(path, 'a') as f:
            f.write('   ')
        with open(path, "rt") as f:
            return f.read()
            
# This function checks the days logged by the user
# to see if qualified for report 
def checkStatusOfLog(app):
    fileCon = writeFileVer2(f"{app.ownerName}.txt")
    print(app.ownerName)
    if 'Yes' or 'No' in fileCon :
        data = ""
        for element in fileCon:
            data += element
        data = data.split('\n')
        for i in range (len(app.daysStatus)):
            if app.daysStatus[i] in fileCon:
                app.dayStatus[i] = 'Logged'
            else:
                 app.dayStatus[i] = 'Not Logged'

                
    else: # This means user is new
        return 
    
    

         
# reDrawAll deals with tbe drawing of the slides using a helper f(x)
def redrawAll(app, canvas):
    
    if app.systemStarted == False and app.curSlide == 0:
        app.main.drawS1(app,canvas,rgbString(243,214,255))
        if app.userReady ==  True:
             app.main.drawS1V2(app,canvas,rgbString(207,168,213))
             
    if app.userReady ==  True and app.nameSaved == True and app.systemStarted == False:
        app.main.dOfTheWeek(app,canvas,rgbString(207,168,213))
        
    if app.systemStarted == True:
        dealWithSlides(app, canvas)
        
    if app.systemStarted == False and app.userReady == False and app.ThankYouPg ==True:
        dealWithSlides(app, canvas)
        



# helper function that deals with which slide to draw depending on the app.curSlide
def dealWithSlides(app, canvas):
    if app.curSlide == 1:app.main.drawS2(app,canvas,rgbString(213,141,200))
    if app.curSlide == 2:app.main.drawS3(app,canvas,rgbString(185,100,170))
    if app.curSlide == 3:app.main.drawS4(app,canvas,rgbString(185,100,170))
    if app.curSlide == 4:app.main.drawS12(app,canvas,rgbString(122,100,170))
    if app.curSlide == 5:app.main.drawS5(app,canvas,rgbString(122,71,145))
    if app.curSlide == 6:app.main.drawS6(app,canvas,rgbString(122,71,145))
    if app.curSlide == 7:app.main.drawS7(app,canvas,rgbString(100,50,120))
    if app.curSlide == 8:app.main.drawS8(app,canvas,rgbString(122,71,145))
    if app.curSlide == 9:app.main.drawS9(app,canvas,rgbString(122,71,145))
    if app.curSlide == 10:app.main.drawS10(app,canvas,rgbString(122,71,145))
    if app.curSlide == 11:app.main.draw10V2(app,canvas,rgbString(122,71,145))
    if app.curSlide == 20:app.main.drawS11(app,canvas,rgbString(172,92,120))
        
runApp(width=1300, height=700)


